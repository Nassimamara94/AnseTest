<?php require_once 'inc/header.inc.php' ?>


<?php require_once 'inc/header.inc.php' ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <title>L'hypnose pour qui ?</title>
</head>
<body>
    <div class="container">
        
        <div class="row">  <!-- debut row -->
            <div class="col-md-6 mt-4">
                <img src="img/photoes-hypnose/couples1.jpg" alt="couple thérapie">
            </div>

             <div class="col-md-6 mt-4">
                 <br>
                  <h4> Pour la thérapie de couple :</h4>
                  <br>
                  <ul>
                     <li>une séance de rencontre avec les deux personnes</li>
                     <li>deux à trois séances individuelles</li>
                     <li> puis une à deux séances en couple (bilan et mise en place des nouvelles bases) </li> 
                   </ul> 
    
                    <p>Le nombre de séances est indiqué simplement à titre indicatif, chaque personne étant différente, on ne saurait déterminer un nombre de séances exact par avance. Chacun a son propre rythme. </p>
             </div>

        </div> <!-- fin row -->

        <br>
         <div class="row"> <!-- debut row-->
             <div class="col-md-6 mt-4">
                 <br>
                  <h4> « Perte de poids » ou « Gagner en légèreté » : </h4>
                  <br>
                  
                 <ul>
                     <li>
                         Une première séance où nous chercherons les raisons principales de votre poids, ce qui vous pèse... depuis quand... Nous analyserons ce que vous avez déjà mis en place auparavant. Il n'y aura pas forcément de techniques d'hypnose ce jour-là car nos échanges pourraient prendre l'intégralité de la séance. Je pourrais déjà vous donner un ordre d'idée sur le nombre de séance sachant que rien n'est figé et que des choses vont bouger </li>
                     <li>
                         Pour la suite, nous ferons des points sur les changements qui s'opèrent entre chaque séance puis nous travaillerons en hypnose pour vous alléger. </li>
                     <li>
                         Je vous proposerai des exercices à faire chez vous pour accompagner notre travail d’allègement de l'esprit.</li>
                 </ul>
             </div>

                <div class="col-md-6 mt-4">                
                 <img src="img/photoes-hypnose/regimes.jpg" alt="perte de poids ">
                </div>

         </div> <!-- fin row -->


           <div class="row">  <!-- debut row -->
                 <div class="col-md-6 mt-4">
                      <img src="img/photoes-hypnose/adultes-adolescents.jpg" alt="couple thérapie">
                 </div>

                 <div class="col-md-6 mt-4 texte ">
                     <br>
                     <h4> Adultes & Adolescents :</h4>
                     <br>
                      <ul>
                        <li>Une première séance nous permettra de définir ensemble vos besoins (1h30 – 1h45) grâce à nos échanges basés sur de la bienveillance. Il n'y aura pas forcément de techniques d'hypnose ce jour-là car nos échanges pourraient prendre l'intégralité de la séance.</li>
                       <li>Par la suite, tout dépendra de l'objet de votre visite puisque nous sommes sur un accompagnement personnalisé et bref. Nous échangerons à ce sujet conjointement.</li>
                      </ul>

                    <p>Le nombre de séances est indiqué simplement à titre indicatif, chaque personne étant différente, on ne saurait déterminer un nombre de séances exact par avance. Chacun a son propre rythme. </p>  
                 </div>
           </div> <!-- fin row -->

        
        <br>
         <div class="row"> <!-- debut row-->
             <div class="col-md-6 mt-4 texte ">
                 <br>
                  <h4>Enfants : </h4>
                  <br>
                  
                 <ul>
                     <li>
                         Une première séance où nous chercherons les raisons principales de votre poids, ce qui vous pèse... depuis quand... Nous analyserons ce que vous avez déjà mis en place auparavant. Il n'y aura pas forcément de techniques d'hypnose ce jour-là car nos échanges pourraient prendre l'intégralité de la séance. Je pourrais déjà vous donner un ordre d'idée sur le nombre de séance sachant que rien n'est figé et que des choses vont bouger </li>
                     <li>
                         Pour la suite, nous ferons des points sur les changements qui s'opèrent entre chaque séance puis nous travaillerons en hypnose pour vous alléger. </li>
                     <li>
                         Je vous proposerai des exercices à faire chez vous pour accompagner notre travail d’allègement de l'esprit.</li>
                 </ul>
             </div>

             <div class="col-md-6 mt-4">                
                 <img src="img/photoes-hypnose/enfants2.jpg" alt="perte de poids ">
             </div>
         </div> <!-- fin row -->



</body>
</html>

<?php require_once 'inc/footer.inc.php' ?>
<?php require_once 'inc/footer.inc.php' ?>