</main> <!-- Fin main -->
<footer class="footer mt-auto p-3y">
    <div class="container mt-5">
        <ul class="nav justify-content-center">
            <li><a href="#" class="col-md-4 col-lg-4 col-sm-12 col-xs-12 btn"><img src="img/f_logo_RGB-Hex-Blue_512.png"
                        alt="logo-facebook" class="face hover"></a></li>
            <li><a href="#" class="col-md-4 col-lg-4 col-sm-12 col-xs-12 btn"><img src="img/linkedin.png"
                        alt="logo-linkedin" class="twit hover"></a></li>
            <li><a href="#" class="col-md-4 col-lg-4 col-sm-12 col-xs-12 btn"><img src="img/twitter.png" r
                        alt="logo-twitter" class="link hover"></a></li>
        </ul>
    </div>
</footer><!-- Fin footer -->

</div> <!-- Fin div container -->
<!-- Lien CDN JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
</script>
<script src="https ://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
</script>
<!-- BS PICKERDATE JS-->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
<script type="text/javascript"
    src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/js/tempusdominus-bootstrap-4.min.js">
</script>
<!-- jQuery perso -->
<script src="js/jQuery.js" type="text/javascript"></script>
</body>

</html>